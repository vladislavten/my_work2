# Электронный документооборот для АлтынБулак

from fpdf import FPDF


pdf = FPDF()

pdf.add_page()

pdf.add_font('times', '', 'font/times.ttf', uni=True)
pdf.add_font('times', 'B', 'font/timesbd.ttf', uni=True)
pdf.add_font('times', 'BI', 'font/timesbi.ttf', uni=True)

pdf.set_text_color(0, 0, 0) # Задаем цвет в RGB все что будет снизу
pdf.set_font('times', '', size=14)

# Создаем шапку документа

pdf.image('logo.jpeg', x=10, y=10, w=50, h=20) # вставляем логотип
top_text = f'Директору\n' \
           f'ТОО "АлтынБулак-Атырау"\n'\
           f'г-же Таировой А.Р\n'\
           f'от Тен Владислава'

x = 130 # x - координата ячейки по горизонтали (от правого края страницы)
y = 15  # y - координата ячейки по вертикали (от верхнего края страницы)
pdf.set_xy(x, y)
pdf.multi_cell(w=70, h=7, txt=top_text, align = 'L',)

# Пишем в центре Служебная записка
pdf.set_font('times', 'B', size=18, )
pdf.text(x=85, y= 90, txt='Служебная записка')




pdf.output(f"documents/First.pdf")

pdf.close()
















# from fpdf import FPDF
#
# # Создаем объект PDF-документа
# pdf = FPDF()
#
# # Добавляем страницу
# pdf.add_page()
#
# # Устанавливаем шрифт и размер
# pdf.set_font("Arial", size=12)
#
# # Устанавливаем координаты и размеры ячейки с таблицей
#
# x = 130 # x - координата ячейки по горизонтали (от правого края страницы)
# y = 15  # y - координата ячейки по вертикали (от верхнего края страницы)
# pdf.set_xy(x, y)
#
# # Создаем таблицу с одной строкой и одним столбцом
# pdf.multi_cell(50, 6, 'kddfkgj kjdfhgkd gkdhfgkdhgkdfhg', align= None)
#
# # Сохраняем PDF-файл
# pdf.output("example.pdf")




